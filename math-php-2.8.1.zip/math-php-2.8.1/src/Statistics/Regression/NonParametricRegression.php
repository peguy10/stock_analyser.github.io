<?php

namespace MathPHP\Statistics\Regression;

abstract class NonParametricRegression extends Regression
{
}
