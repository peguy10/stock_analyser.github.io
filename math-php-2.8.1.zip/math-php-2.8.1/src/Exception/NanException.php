<?php

namespace MathPHP\Exception;

class NanException extends MathException
{
}
