<?php

namespace MathPHP\Exception;

class SingularMatrixException extends MatrixException
{
}
