<?php

namespace MathPHP\Exception;

class IncorrectTypeException extends MathException
{
}
