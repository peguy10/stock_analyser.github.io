<?php

namespace MathPHP\Exception;

class VectorException extends MathException
{
}
