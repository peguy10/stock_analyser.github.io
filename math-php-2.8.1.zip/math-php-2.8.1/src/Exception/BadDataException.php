<?php

namespace MathPHP\Exception;

class BadDataException extends MathException
{
}
