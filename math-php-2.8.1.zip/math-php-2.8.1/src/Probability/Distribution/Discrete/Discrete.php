<?php

namespace MathPHP\Probability\Distribution\Discrete;

abstract class Discrete extends \MathPHP\Probability\Distribution\Distribution
{
}
